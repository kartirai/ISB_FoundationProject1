Save all the files in folder in default jupyter directory & run below command from jupyter notebook

!streamlit run stream.py